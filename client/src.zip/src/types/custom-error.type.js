export interface CustomError extends Error {
  errorCode?;
}
