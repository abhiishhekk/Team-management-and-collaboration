import React from "react";

const Unauthorized = () => {
  return Unauthorized</div>;
};

export default Unauthorized;
